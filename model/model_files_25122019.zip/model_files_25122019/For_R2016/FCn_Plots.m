close all
clc 


figure
plot(Po.signals(1).values,Po.signals(2).values,'r','LineWidth',3)
hold on
plot(P1.signals(1).values,P1.signals(2).values,'b','LineWidth',3)
hold on
plot(P2.signals(1).values,P2.signals(2).values,'g','LineWidth',3)
hold on
plot(P3.signals(1).values,P3.signals(2).values,'k','LineWidth',3)
hold on
plot(P4.signals(1).values,P4.signals(2).values,'m','LineWidth',3)
title("Positions of centeroids of the payload and the drones in X-Y plane")
xlabel('X(m)')
ylabel('Y(m)')
legend('Payload','Drone-1','Drone-2','Drone-3','Drone-4')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid


figure
subplot(3,1,1)
plot(e_cons_1.time,e_cons_1.signals(1).values,'b','LineWidth',3)
hold on
plot(e_cons_2.time,e_cons_2.signals(1).values,'g','LineWidth',3)
hold on
plot(e_cons_3.time,e_cons_3.signals(1).values,'k','LineWidth',3)
hold on
plot(e_cons_4.time,e_cons_4.signals(1).values,'m','LineWidth',3)
xlabel('time(s)')
ylabel('e_x(m)')
legend('Drone-1','Drone-2','Drone-3','Drone-4')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("Consensus errors for all of the drones in 3D motion")
subplot(3,1,2)
plot(e_cons_1.time,e_cons_1.signals(2).values,'b','LineWidth',3)
hold on
plot(e_cons_2.time,e_cons_2.signals(2).values,'g','LineWidth',3)
hold on
plot(e_cons_3.time,e_cons_3.signals(2).values,'k','LineWidth',3)
hold on
plot(e_cons_4.time,e_cons_4.signals(2).values,'m','LineWidth',3)
xlabel('time(s)')
ylabel('e_y(m)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
subplot(3,1,3)
plot(e_cons_1.time,e_cons_1.signals(3).values,'b','LineWidth',3)
hold on
plot(e_cons_2.time,e_cons_2.signals(3).values,'g','LineWidth',3)
hold on
plot(e_cons_3.time,e_cons_3.signals(3).values,'k','LineWidth',3)
hold on
plot(e_cons_4.time,e_cons_4.signals(3).values,'m','LineWidth',3)
xlabel('time(s)')
ylabel('e_z(m)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid


figure
subplot(3,1,1)
plot(Vo.time,Vo.signals(1).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('V_x(m/s)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("Velocity of the payload centroid in 3D motion")
subplot(3,1,2)
plot(Vo.time,Vo.signals(2).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('V_y(m/s)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
subplot(3,1,3)
plot(Vo.time,Vo.signals(3).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('V_z(m/s)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid


figure
subplot(3,1,1)
plot(Phio.time,Phio.signals(1).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('phi(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("Euler angles of the payload in 3D motion")
subplot(3,1,2)
plot(Phio.time,Phio.signals(2).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('theta(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
subplot(3,1,3)
plot(Phio.time,Phio.signals(3).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('psi(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid


figure
subplot(2,2,1)
plot(Alpha_des.time,Alpha_des.signals(1).values,'--r','LineWidth',6)
hold on
plot(Angles1.time,Angles1.signals(1).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('alpha(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of alpha for Drone-1")
legend('desired','actual')
subplot(2,2,2)
plot(Alpha_des.time,Alpha_des.signals(2).values,'--r','LineWidth',6)
hold on
plot(Angles2.time,Angles2.signals(1).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('alpha(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of alpha for Drone-2")
legend('desired','actual')
subplot(2,2,3)
plot(Alpha_des.time,Alpha_des.signals(3).values,'--r','LineWidth',6)
hold on
plot(Angles3.time,Angles3.signals(1).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('alpha(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of alpha for Drone-3")
legend('desired','actual')
subplot(2,2,4)
plot(Alpha_des.time,Alpha_des.signals(4).values,'--r','LineWidth',6)
hold on
plot(Angles4.time,Angles4.signals(1).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('alpha(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of alpha for Drone-4")
legend('desired','actual')


figure
subplot(2,2,1)
plot(Beta_des.time,Beta_des.signals(1).values,'--r','LineWidth',6)
hold on
plot(Angles1.time,Angles1.signals(2).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('beta(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of beta for Drone-1")
legend('desired','actual')
subplot(2,2,2)
plot(Beta_des.time,Beta_des.signals(2).values,'--r','LineWidth',6)
hold on
plot(Angles2.time,Angles2.signals(2).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('beta(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of beta for Drone-2")
legend('desired','actual')
subplot(2,2,3)
plot(Beta_des.time,Beta_des.signals(3).values,'--r','LineWidth',6)
hold on
plot(Angles3.time,Angles3.signals(2).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('beta(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of beta for Drone-3")
legend('desired','actual')
subplot(2,2,4)
plot(Beta_des.time,Beta_des.signals(4).values,'--r','LineWidth',6)
hold on
plot(Angles4.time,Angles4.signals(2).values,'b','LineWidth',3)
xlabel('time(s)')
ylabel('beta(rad)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("values of beta for Drone-4")
legend('desired','actual')

figure
subplot(2,2,1)
plot(f_des.time,f_des.signals(1).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('f_1(N)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("value of the desired force in link-1")
subplot(2,2,2)
plot(f_des.time,f_des.signals(2).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('f_2(N)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("value of the desired force in link-2")
subplot(2,2,3)
plot(f_des.time,f_des.signals(3).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('f_3(N)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("value of the desired force in link-3")
subplot(2,2,4)
plot(f_des.time,f_des.signals(4).values,'r','LineWidth',3)
xlabel('time(s)')
ylabel('f_4(N)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("value of the desired force in link-4")


figure
subplot(3,1,1)
plot(U1.time,U1.signals(1).values,'b','LineWidth',3)
hold on
plot(U2.time,U2.signals(1).values,'g','LineWidth',3)
hold on
plot(U3.time,U3.signals(1).values,'k','LineWidth',3)
hold on
plot(U4.time,U4.signals(1).values,'m','LineWidth',3)
xlabel('time(s)')
ylabel('U_x(N)')
legend('Drone-1','Drone-2','Drone-3','Drone-4')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
title("Requested force components at all of the drones in the inertial frame for 3D motion")
subplot(3,1,2)
plot(U1.time,U1.signals(2).values,'b','LineWidth',3)
hold on
plot(U2.time,U2.signals(2).values,'g','LineWidth',3)
hold on
plot(U3.time,U3.signals(2).values,'k','LineWidth',3)
hold on
plot(U4.time,U4.signals(2).values,'m','LineWidth',3)
xlabel('time(s)')
ylabel('U_y(N)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid
subplot(3,1,3)
plot(U1.time,U1.signals(3).values,'b','LineWidth',3)
hold on
plot(U2.time,U2.signals(3).values,'g','LineWidth',3)
hold on
plot(U3.time,U3.signals(3).values,'k','LineWidth',3)
hold on
plot(U4.time,U4.signals(3).values,'m','LineWidth',3)
xlabel('time(s)')
ylabel('U_z(N)')
set(gca,'FontSize',16)
set(gca,'FontWeight','bold')
grid

